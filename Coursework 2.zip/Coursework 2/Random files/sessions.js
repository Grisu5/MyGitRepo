sessions = [
    {   
        id: 111,
        title: "Music",
        price: 500,
        icon: "fa-solid fa-music",
        spaces: 5,
        location: "Omdurman"
    },

    {   
            id: 112,
            title: "Dance",
            price: 700,
            icon: "fa-solid fa-drum",
            spaces: 5,
            location: "Khartoum"

    },

    {
            id: 113,
            title: "Photography",
            price: 400,
            icon: "fa-solid fa-image",
            spaces: 5,
            location: "Bahri"

    },

    {
            id: 114,
            title: "Football",
            price: 800,
            icon: "fa-regular fa-futbol",
            spaces: 5,
            location: "Khartoum"

    },
      
    {
            id: 115,
            title: "Film",
            price: 700,
            icon: "fa-solid fa-film",
            spaces: 5,
            location: "Bahri"

    },

    {
            id: 116,
            title: "Programming",
            price: 100,
            icon: "fa-solid fa-code",
            spaces: 5,
            location: "Omdurman"

    },

    {
            id: 117,
            title: "Graphics Design",
            price: 300,
            icon: "fa-solid fa-object-group",
            spaces: 5,
            location: "Bahri"

    },

    {
            id: 118,
            title: "Fashion",
            price: 400,
            icon: "fa-solid fa-vest-patches",
            spaces: 5,
            location: "Bahri"
    }, 

    {
            id: 119,
            title: "Creative writing",
            price: 100,
            icon: "fa-solid fa-pen",
            spaces: 5,
            location: "Khartoum"

    },

    {
            id: 110,
            title: "Mindfullness",
            price: 50,
            icon: "fa-regular fa-circle",
            spaces: 5,
            location: "Omdurman"

    }, 
     
]